package com.jean.emp3;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private List<ShoppingList> listaShopping;
    private ListView lwFromListaShopping;
    private ArrayAdapter<ShoppingList> adapter;
    public int userID;

    FloatingActionButton krogec;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Intent intent = getIntent();
//        userID = Integer.parseInt(intent.getStringExtra("userID"));

        krogec = (FloatingActionButton) findViewById(R.id.krogec);
        krogec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this, AddShoppingList.class);
                MainActivity.this.startActivity(intent1);
            }
        });

        lwFromListaShopping = (ListView) findViewById(R.id.shoppingListView);
        listaShopping = new ArrayList<ShoppingList>();

        fillList();

        adapter = new ArrayAdapter<ShoppingList>(this, R.layout.list_item, listaShopping);

        lwFromListaShopping.setAdapter(adapter);
        lwFromListaShopping.setOnItemClickListener(viewShoppingListListener);

    }

    AdapterView.OnItemClickListener viewShoppingListListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Intent a = new Intent(MainActivity.this, ShoppingListPage.class);

            a.putExtra("serializedShoppingList", (ShoppingList) lwFromListaShopping.getItemAtPosition(position));

            /*ShoppingList b = (ShoppingList) lwFromListaShopping.getItemAtPosition(position);
            String ime = b.toString();
            String itemsID = "" + b.getID();
            a.putExtra("ShoppingListID", itemsID);
            //a.putExtra("neki", itemsID);*/


            startActivity(a);
        }
    };

    private void fillList() {

        for (int i = 0; i < 20; i++) {
            String a = "jean" + i;
            listaShopping.add(new ShoppingList(a));
        }

    }
    public void getShoppingListsByUserID(int ID){
        /**
         * vse elemente iz Jsona se pravi vse Shopping liste spremenim v objekte ShoppinList in jih
         * dodam v this.listaShopping tako da imam arrayLsito iz objektov shoppingList ki pripadajo
         * temu userju
         */
    }



}

