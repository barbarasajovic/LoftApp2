package com.jean.emp3;

/**
 * Created by jeanm on 03/01/2018.
 */

public class User {
    public String userName;
    public String userSurname;
    public int userPhonenumber;
    public String userUSERNAME;
    public String userEmail;
    private String userPassword;

    public int userID;
    public int userSho_ID;

}
