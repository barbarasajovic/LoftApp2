package com.jean.emp3;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by jeanm on 03/01/2018.
 */

public class ShoppingList implements Serializable {

    public ArrayList<User> shoppingListParticipants;
    public ArrayList<Item> shoppingListItems;
    public int shoppingListtotalPrice;

    public String shoppingListName;
    public int shoppingListID;

    ShoppingList (String name){
        this.shoppingListName = name;

    }
    @Override
    public String toString() {
        return shoppingListName;
    }
    public int getID() {
        return this.shoppingListID;
    }

}
