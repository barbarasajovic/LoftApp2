package com.jean.emp3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class ShoppingListPage extends AppCompatActivity {

    private TextView tvIme;

    private List<Item> listaItems;
    private ListView lwFromListaItems;
    private ArrayAdapter<Item> adapter;
    private ShoppingList currentShoppingList;
    private List<User> participansOfTheList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopping_list_page);

        Toolbar myToolbar = (Toolbar) findViewById(R.id.my_toolbar);
        setSupportActionBar(myToolbar);
        getSupportActionBar().setTitle("Shopping List");

        tvIme = (TextView) findViewById(R.id.tvImeLayout);
        Intent intent = getIntent();

        currentShoppingList = (ShoppingList) intent.getSerializableExtra("serializedShoppingList");

        lwFromListaItems = (ListView) findViewById(R.id.shoppingListView1);
       // listaItems = new ArrayList<Item>();
        listaItems = currentShoppingList.shoppingListItems;
        participansOfTheList = currentShoppingList.shoppingListParticipants;

        getShoppingListByID(0);

        adapter = new ArrayAdapter<Item>(this, R.layout.shopping_list_page_item, listaItems);

        lwFromListaItems.setAdapter(adapter);

    }
    private void getShoppingListByID(int ID){
        /**
         * to ne rabim več ker sm objekt prenesel preko intenta
         */
        for (int i = 0; i < 20; i++) {
            String a = "izdelek " + i;
            listaItems.add(new Item(a, i));
        }


    }

    private void getParticipansPyShoID(int ID) {
        /**
         * pridobim vse ki so vključeni v ta shopping list in jih izpisem v textView
         */
    }

}
