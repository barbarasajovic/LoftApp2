package com.jean.emp3;

/**
 * Created by jeanm on 03/01/2018.
 */

public class Item {
    private int itemID;
    public String itemName;
    private int itemSho_ID;
    public int itemPrice = -1;

    Item(String name, int itemPrice) {
        this.itemName = name;
        this.itemPrice = itemPrice;
    }
    @Override
    public String toString() {
        return itemName + " " + itemPrice;
    }
}
