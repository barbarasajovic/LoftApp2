package com.jean.emp3;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class AddShoppingList extends AppCompatActivity {

    EditText etName, etFriends;
    String[] friendsList;

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_shopping_list);

        etName = (EditText) findViewById(R.id.etNameList);
        etFriends = (EditText) findViewById(R.id.etFriends);
        friendsList = etFriends.getText().toString().split("\\s+");


        Button butDoneSave = (Button) findViewById(R.id.buttonDone);
        butDoneSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveListToDatabase();
                Intent intent = new Intent(AddShoppingList.this, MainActivity.class);
                AddShoppingList.this.startActivity(intent);
            }
        });

    }

    public void saveListToDatabase() {

    }
}
